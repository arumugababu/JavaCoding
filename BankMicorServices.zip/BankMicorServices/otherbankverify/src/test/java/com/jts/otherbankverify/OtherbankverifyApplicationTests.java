package com.jts.otherbankverify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtherbankverifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
