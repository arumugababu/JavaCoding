package com.jts.otherbankverify;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.jts.otherbankverify.model.BothbankModel;
import com.jts.otherbankverify.model.IciciModel;
import com.jts.otherbankverify.model.SbiBankModel;

@RestController
@RequestMapping("/bankverfiy")
public class Apibothbank {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@RequestMapping("/mytest")
	public String myTest(){
		
		return "My test page is successs";
	}
	
	
	@RequestMapping("/searchLoansbi")
	public SbiBankModel getBanksbi(@RequestParam("panNo") String panNo) {	
		

		SbiBankModel sbiBankModel = restTemplate.getForObject("http://banksbi-ms" +"/sbi/searchLoan/"+panNo,
				SbiBankModel.class); 

		return sbiBankModel;

	}
	
	@RequestMapping("/searchLoanicici")
	public IciciModel getBankicici(@RequestParam("panNo") String panNo) {	
		

		IciciModel icicibankModel = restTemplate.getForObject("http://bankicici-ms" +"/icici/searchLoan/"+panNo,
				IciciModel.class); 

		return icicibankModel;

	}
	
	@RequestMapping("/allBankSearch")
	public BothbankModel getBothbankVerfiction(@RequestParam("panNo") String panNo){
		
		BothbankModel bothbankModelList = new BothbankModel();
		
		IciciModel icicibankList = restTemplate.getForObject("http://bankicici-ms" +"/icici/searchLoan/"+panNo,
				IciciModel.class); 
		
		SbiBankModel sbiBankList = restTemplate.getForObject("http://banksbi-ms" +"/sbi/searchLoan/"+panNo,
				SbiBankModel.class);
		
		
		bothbankModelList.setIciciModelList(icicibankList);
		
		bothbankModelList.setSbiBankList(sbiBankList);
		
		return bothbankModelList;
		
		
	}
	

}
