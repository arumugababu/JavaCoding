package com.jts.otherbankverify.model;

public class BothbankModel {
	
	private IciciModel iciciModelList;
	private SbiBankModel sbiBankList;
	public IciciModel getIciciModelList() {
		return iciciModelList;
	}
	public void setIciciModelList(IciciModel iciciModelList) {
		this.iciciModelList = iciciModelList;
	}
	public SbiBankModel getSbiBankList() {
		return sbiBankList;
	}
	public void setSbiBankList(SbiBankModel sbiBankList) {
		this.sbiBankList = sbiBankList;
	}
	
	

}
