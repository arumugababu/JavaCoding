package com.jts.banksbi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanksbiApplicationTests {

	@Test
	void contextLoads() {
	}

}
