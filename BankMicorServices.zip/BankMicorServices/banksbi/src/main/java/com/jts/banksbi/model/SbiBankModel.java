package com.jts.banksbi.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SbiBankdb")
public class SbiBankModel {

	@Id
	private String sbiGPanNumber;
	private String sbiGPanName;
	private String sbiGBankName;
	private String sbiGBankBranch;
	private String sbiGBankLoanAmount;
	private String sbiGBankCurrentPenAmout;
	private int sbiGPanAccount;

	public String getSbiGPanNumber() {
		return sbiGPanNumber;
	}

	public void setSbiGPanNumber(String sbiGPanNumber) {
		this.sbiGPanNumber = sbiGPanNumber;
	}

	public String getSbiGPanName() {
		return sbiGPanName;
	}

	public void setSbiGPanName(String sbiGPanName) {
		this.sbiGPanName = sbiGPanName;
	}

	public String getSbiGBankName() {
		return sbiGBankName;
	}

	public void setSbiGBankName(String sbiGBankName) {
		this.sbiGBankName = sbiGBankName;
	}

	public String getSbiGBankBranch() {
		return sbiGBankBranch;
	}

	public void setSbiGBankBranch(String sbiGBankBranch) {
		this.sbiGBankBranch = sbiGBankBranch;
	}

	public String getSbiGBankLoanAmount() {
		return sbiGBankLoanAmount;
	}

	public void setSbiGBankLoanAmount(String sbiGBankLoanAmount) {
		this.sbiGBankLoanAmount = sbiGBankLoanAmount;
	}

	public String getSbiGBankCurrentPenAmout() {
		return sbiGBankCurrentPenAmout;
	}

	public void setSbiGBankCurrentPenAmout(String sbiGBankCurrentPenAmout) {
		this.sbiGBankCurrentPenAmout = sbiGBankCurrentPenAmout;
	}

	public int getSbiGPanAccount() {
		return sbiGPanAccount;
	}

	public void setSbiGPanAccount(int sbiGPanAccount) {
		this.sbiGPanAccount = sbiGPanAccount;
	}

}
