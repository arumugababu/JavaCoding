package com.jts.banksbi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.jts.banksbi.dao.SbiBankdao;
import com.jts.banksbi.model.SbiBankModel;

@Service
public class SbiBankService {

	@Autowired
	private SbiBankdao sbiBankdao;

	public SbiBankModel addLoanBanker(SbiBankModel iciciModel) {

		return sbiBankdao.save(iciciModel);

	}

	public Optional<SbiBankModel> searchLoan(String panNo) {

		return sbiBankdao.findById(panNo);

	}

	public List<SbiBankModel> getAllLoan() {
		return (List<SbiBankModel>) sbiBankdao.findAll();
	}

	public void deleteLoan(@PathVariable String panNo) {
		sbiBankdao.deleteById(panNo);
	}

}
