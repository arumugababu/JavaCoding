package com.jts.banksbi.dao;

import org.springframework.data.repository.CrudRepository;

import com.jts.banksbi.model.SbiBankModel;

public interface SbiBankdao extends CrudRepository<SbiBankModel,String> {

}
