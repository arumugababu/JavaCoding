package com.jts.bankicici.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "iciciBankdb")
public class IciciModel {

	@Id
	private String GPanNumber;

	private String GPanName;
	private String GBankName;
	private String GBankBranch;
	private String GBankLoanAmount;
	private String GBankCurrentPenAmout;
	private int GPanAccount;

	public String getGPanNumber() {
		return GPanNumber;
	}

	public void setGPanNumber(String gPanNumber) {
		GPanNumber = gPanNumber;
	}

	public int getGPanAccount() {
		return GPanAccount;
	}

	public void setGPanAccount(int gPanAccount) {
		GPanAccount = gPanAccount;
	}

	public String getGPanName() {
		return GPanName;
	}

	public void setGPanName(String gPanName) {
		GPanName = gPanName;
	}

	public String getGBankName() {
		return GBankName;
	}

	public void setGBankName(String gBankName) {
		GBankName = gBankName;
	}

	public String getGBankBranch() {
		return GBankBranch;
	}

	public void setGBankBranch(String gBankBranch) {
		GBankBranch = gBankBranch;
	}

	public String getGBankLoanAmount() {
		return GBankLoanAmount;
	}

	public void setGBankLoanAmount(String gBankLoanAmount) {
		GBankLoanAmount = gBankLoanAmount;
	}

	public String getGBankCurrentPenAmout() {
		return GBankCurrentPenAmout;
	}

	public void setGBankCurrentPenAmout(String gBankCurrentPenAmout) {
		GBankCurrentPenAmout = gBankCurrentPenAmout;
	}

}
