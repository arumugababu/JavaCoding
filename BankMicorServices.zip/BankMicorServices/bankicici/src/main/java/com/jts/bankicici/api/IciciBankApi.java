package com.jts.bankicici.api;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jts.bankicici.model.IciciModel;
import com.jts.bankicici.service.IciciService;



@RestController
@RequestMapping("/icici")
public class IciciBankApi {
	
	@Autowired
	private IciciService iciciService;
	
	
	@RequestMapping("/test")
	public  String sbiTest(){
		
		return "ICICI bank Inside";
		
	}
	
	//@RequestMapping("/addLoan")
	@PostMapping("/addLoan")
	public IciciModel addLoanBanker(@RequestBody IciciModel iciciModel){
		
		return iciciService.addLoanBanker(iciciModel);
		
	}
	
	//@RequestMapping("/searchLoan/{panNo}")
	@GetMapping("/searchLoan/{panNo}")
	public Optional<IciciModel> searchLoan(@PathVariable("panNo") String panNo ){
		
		System.out.println("======ICICI BANK SEARCHlOAN iNSIDE"+panNo);
		
		Optional<IciciModel> iciciModel = iciciService.searchLoan(panNo);
		
		System.out.println("======ICICI BANK SEARCHlOAN OUT SIZE");
		
		return iciciModel;
		
	}
	
	@GetMapping("/searchLoan")
	public List<IciciModel> getAllLoan(){
		
		return iciciService.getAllLoan();
		
	}
	
	@DeleteMapping("/deletLoan/{panNo}")
	public void deleteLoan(@PathVariable String panNo){
		
		iciciService.deleteLoan(panNo);
	}

}
