package com.jts.bankicici.dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jts.bankicici.model.IciciModel;


@Repository
public interface IciciDao extends CrudRepository<IciciModel, String> {


}
