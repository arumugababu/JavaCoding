package com.jts.bankicici.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.jts.bankicici.dao.IciciDao;
import com.jts.bankicici.model.IciciModel;

@Service
public class IciciService {

	@Autowired
	private IciciDao iciciDao;

	public IciciModel addLoanBanker(IciciModel iciciModel) {

		return iciciDao.save(iciciModel);

	}

	public Optional<IciciModel> searchLoan(String panNo) {
		System.out.println("======ICICI BANK SER==========");

		return iciciDao.findById(panNo);

	}

	public List<IciciModel> getAllLoan() {
		// TODO Auto-generated method stub
		return (List<IciciModel>) iciciDao.findAll();
	}

	public void deleteLoan(@PathVariable String panNo) {
		// TODO Auto-generated method stub
		iciciDao.deleteById(panNo);
	}

}
