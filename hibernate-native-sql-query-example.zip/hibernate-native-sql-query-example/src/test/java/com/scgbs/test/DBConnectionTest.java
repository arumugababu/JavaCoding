package com.scgbs.test;

import java.sql.Connection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.scgbs.util.DBConnectionProvider;

public class DBConnectionTest
{
	public static void main ( String [] args ) throws Exception
	{
		// Class.forName("com.mysql.jdbc.Driver");
		DBConnectionProvider.getInstance ();
		Connection connection = DBConnectionProvider.getConnection ();
		if ( connection != null )
		{
			System.out.println ( "Connection opened" );
		}

		DBConnectionProvider.closeConnection ();
		System.out.println ( "Connection Closed" );
		System.out.println ( "Done" );

		String sqlQuery = "SELECT E.EMP_ID AS EEMPID,E.NAME AS ENAME,E.DESIGNATION AS EDESIGNATION,D.NAME AS DNAME FROM  EMPLOYEE E, DEPARTMENT D WHERE E.DPT_ID=D.DPT_ID";

		String pattern = "SELECT(.*?)FROM";
		Pattern r = Pattern.compile ( pattern, Pattern.DOTALL );
		Matcher m = r.matcher ( sqlQuery );

		if ( m.find () )
		{
			System.out.println ( "Found columns Names: " + m.group ( 1 ) );
		}

		String patternTable = "FROM(.*?)WHERE";
		Pattern rtbl = Pattern.compile ( patternTable, Pattern.DOTALL );
		Matcher mtbl = rtbl.matcher ( sqlQuery );

		while ( mtbl.find () )
		{
			System.out.println ( "Found Table Names: " + mtbl.group ( 1 ) );
		}
	}
}
