package com.scgbs.util;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnectionProvider implements Cloneable, Serializable
{
	private static final long			serialVersionUID	= 1L;
	private static DBConnectionProvider	instance			= null;
	private static Connection			connection;
	private static Properties properties = new Properties ();
	private DBConnectionProvider () throws Exception
	{
		try
		{
			Class.forName (properties.getProperty ( Constants.DB_DRIVAER ));
			connection = DriverManager.getConnection ( properties.getProperty ( Constants.DB_URL ), properties.getProperty ( Constants.DB_USER ), properties.getProperty ( Constants.DB_PASS ) );
		}
		catch ( ClassNotFoundException ex )
		{
			System.out.println ( "Database Connection Creation Failed : " + ex.getMessage () );
		}
	}

	public static DBConnectionProvider getInstance () throws Exception
	{// Single Checked
		if ( instance == null )
		{
			// synchronized block
			synchronized ( DBConnectionProvider.class )
			{
				// Double checked
				if ( instance == null )
				{
					properties.load ( DBConnectionProvider.class.getResourceAsStream ( Constants.DB_CONFIG_FILE ) );
					instance = new DBConnectionProvider ();
				}
			}
		}
		return instance;
	}

	@Override
	protected Object clone () throws CloneNotSupportedException
	{
		return instance;
	}

	public static Connection getConnection ()
	{
		return connection;
	}

	public static void closeConnection () throws SQLException
	{
		if ( connection != null )
		{
			connection.close ();
		}
	}
}
