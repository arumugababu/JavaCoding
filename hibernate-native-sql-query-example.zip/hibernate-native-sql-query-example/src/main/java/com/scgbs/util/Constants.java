package com.scgbs.util;

public final class Constants
{
	private Constants ()
	{
		// No need to instantiate the class, we can hide its constructor
	}
	public static final String	QUERY_SPLIT_SELECT_FROM	= "SELECT(.*?)FROM";
	public static final String	DB_CONFIG_FILE			= "/config/dbconfig.properties";
	public static final String	DB_DRIVAER				= "db.driver";

	public static final String	DB_URL					= "db.url";
	public static final String	DB_USER					= "db.username";
	public static final String	DB_PASS					= "db.password";

	public static final String	COMMA					= ",";

	public static final String	SELECT					= "SELECT ";
	public static final String	CAPITAL_AS				= " AS ";
	public static final String	SMALL_AS				= " as ";
	public static final String	CAPITAL_FROM			= " FROM ";
	public static final String	SMALL_FROM				= " from ";

	public static final String	EXCEL_SHEET_NAME			= "Table Details";

	public static final String	EXCEL_RESULT_FILE_NAME	= "results.xlsx";

}
