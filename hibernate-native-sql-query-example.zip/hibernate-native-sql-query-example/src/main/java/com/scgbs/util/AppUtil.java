package com.scgbs.util;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public final class AppUtil
{
	private static final Logger logger = Logger.getLogger ( AppUtil.class.getName () );
	public static String [] getTableColumns ( String sqlQuery )
	{
		String [] strColumnArray = null;
		String pattern = Constants.QUERY_SPLIT_SELECT_FROM;
		Pattern r = Pattern.compile ( pattern, Pattern.DOTALL );
		Matcher m = r.matcher ( sqlQuery );
		if ( m.find () )
		{
			strColumnArray = m.group ( 1 ).split ( Constants.COMMA );
		}
		return strColumnArray;
	}

	public static String prepareQuery ( String [] strColumnArray )
	{
		StringBuilder builder = new StringBuilder ();
		for ( int i = 0; i < strColumnArray.length; i++ )
		{
			String strColumnName = strColumnArray[i].trim ();
			if ( i == strColumnArray.length - 1 )
			{
				builder.append ( strColumnName ).append ( Constants.CAPITAL_AS ).append ( removeDOT ( strColumnName ) );
			}
			else
			{
				builder.append ( strColumnName ).append ( Constants.CAPITAL_AS ).append ( removeDOT ( strColumnName ) ).append ( Constants.COMMA );
			}
		}
		return builder.toString ();
	}

	public static String sqlQuery ( String sqlQuery )
	{
		StringBuffer buffer = new StringBuffer ();
		if ( !sqlQuery.contains ( Constants.CAPITAL_AS ) && !sqlQuery.contains ( Constants.SMALL_AS ) )
		{
			String [] getTableColumns = AppUtil.getTableColumns ( sqlQuery );
			if ( getTableColumns.length > 0 )
			{
				String prepareQueryColumns = AppUtil.prepareQuery ( getTableColumns );
				if ( sqlQuery.contains ( Constants.CAPITAL_FROM ) || sqlQuery.contains ( Constants.SMALL_FROM ) )
				{
					String [] strArray = sqlQuery.split ( Constants.CAPITAL_FROM );
					if ( strArray.length == 0 )
					{
						strArray = sqlQuery.split ( Constants.SMALL_FROM );
					}
					buffer.append ( Constants.SELECT + prepareQueryColumns + Constants.CAPITAL_FROM + strArray[1] );
				}
			}
		}
		else
		{
			buffer.append ( sqlQuery );
		}
		return buffer.toString ();
	}

	public static String removeDOT ( String str )
	{
		return str.replaceAll ( "[-+.^:,]", "" );

	}

	public static List <String> getQueryColumns ( Connection connection, String sqlQuery )
	{
		List <String> list = new ArrayList <String> ();
		try
		{
			StringBuffer buffer = new StringBuffer ();
			PreparedStatement mystmt = connection.prepareStatement ( sqlQuery );
			ResultSetMetaData mymeta = mystmt.getMetaData ();
			int numcols = mymeta.getColumnCount ();
			for ( int i = 1; i <= numcols; i++ )
			{
				buffer.append ( i <= numcols - 1 ? mymeta.getColumnLabel ( i ) + Constants.COMMA : mymeta.getColumnLabel ( i ) );
			}
			list.add ( buffer.toString () );
		}
		catch ( Exception e )
		{
			logger.error ( "getQueryColumns >> Error : " + e.getMessage () );
		}
		return list;
	}

	public static List <String> getQueryDatas ( Connection connection, String sqlQuery, List <String> mapColumns )
	{
		List <String> mapColumnsValues = new ArrayList <String> ();
		try
		{
			String [] strColumns = mapColumns.get ( 0 ).split ( Constants.COMMA );
			Statement stmt = connection.createStatement ();
			ResultSet rs = stmt.executeQuery ( sqlQuery );
			while ( rs.next () )
			{
				StringBuffer buffer = new StringBuffer ();
				for ( int j = 0; j < strColumns.length; j++ )
				{
					buffer.append ( j < strColumns.length - 1 ? rs.getString ( strColumns[j] ) + Constants.COMMA : rs.getString ( strColumns[j] ) );
				}
				mapColumnsValues.add ( buffer.toString () );
			}
			logger.info ( "Total Record :" + mapColumnsValues.size () );
		}
		catch ( Exception e )
		{
			logger.error ( "getQueryDatas >> Error : " + e.getMessage () );
		}
		return mapColumnsValues;
	}

	public static void writeExcel ( List <String> writeValues )
	{
		try
		{
			XSSFWorkbook workbook = new XSSFWorkbook ();
			// Creating a blank Excel sheet
			XSSFSheet sheet = workbook.createSheet ( Constants.EXCEL_SHEET_NAME );

			Map <String, Object []> prepareWriteData = prepareWriteData ( writeValues );
			if ( prepareWriteData.size () > 0 )
			{
				writeValues ( prepareWriteData, sheet );
				writeExcelFiles ( workbook );
				workbook.close ();
			}
			logger.info ( "results.xlsx written successfully on disk." );
		}
		catch ( Exception e )
		{
			logger.error ( " writeExcel >>> Error : " + e.getMessage () );
		}
	}

	public static Map <String, Object []> prepareWriteData ( List <String> writeValues )
	{
		Map <String, Object []> data = new TreeMap <String, Object []> ();
		String [] strings = writeValues.stream ().toArray ( n -> new String[n] );
		int rowNumber = 1;
		for ( String string : strings )
		{
			String [] s = string.split ( Constants.COMMA );
			data.put ( String.valueOf ( rowNumber ), s );
			rowNumber++;
		}
		return data;
	}

	public static void writeValues ( Map <String, Object []> prepareWriteData, XSSFSheet sheet )
	{
		Set <String> keyset = prepareWriteData.keySet ();
		int rownum = 0;
		for ( String key : keyset )
		{
			// Creating a new row in the sheet
			Row row = sheet.createRow ( rownum++ );
			Object [] objArr = prepareWriteData.get ( key );
			int cellnum = 0;
			for ( Object obj : objArr )
			{
				Cell cell = row.createCell ( cellnum++ );
				if ( obj instanceof String )
					cell.setCellValue ( (String) obj );
				else if ( obj instanceof Integer )
					cell.setCellValue ( (Integer) obj );
			}
		}
	}

	public static void writeExcelFiles ( XSSFWorkbook workbook )
	{
		FileOutputStream out;
		try
		{
			out = new FileOutputStream ( new File ( Constants.EXCEL_RESULT_FILE_NAME ) );
			workbook.write ( out );
			// Closing file output connections
			out.close ();
		}
		catch ( Exception e )
		{
			logger.error ( " writeExcelFiles >>> Error : " + e.getMessage () );
			e.printStackTrace ();
		}

	}
}
