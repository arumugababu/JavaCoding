package com.student.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.student.model.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
	
	// Query method to find students with percentage greater than the given value
    List<Student> findByPercentageGreaterThan(double percentage);

    // Query method to find students by name (case-insensitive)
    List<Student> findByNameContainingIgnoreCase(String name);
    
    Page<Student> findAll(Pageable pageable);
}
