package com.student.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.student.dao.StudentRepository;
import com.student.model.Student;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }

    public void saveStudent(Student student) {
        // Calculate total and percentage here
        int totalMarks = student.getTamil() + student.getEnglish() + student.getMaths() +
                student.getScience() + student.getSocialScience();
        double percentage = totalMarks / 5.0;

        student.setTotal(totalMarks);
        student.setPercentage(percentage);

        studentRepository.save(student);
    }

    public void deleteStudentById(Long id) {
        studentRepository.deleteById(id);
    }
    
    // Service method to get students with percentage greater than the given value
    public List<Student> getStudentsWithPercentageGreaterThan(double percentage) {
        return studentRepository.findByPercentageGreaterThan(percentage);
    }

    // Service method to get students by name
    public List<Student> getStudentsByName(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name);
    }

    // Service method to get a student by ID
    public Student getStudentById(long id) {
        return studentRepository.findById(id).orElse(null);
    }

    // Service method to get students by percentage greater than the given value
    public List<Student> getStudentsByPercentageGreaterThan(double percentage) {
        return studentRepository.findByPercentageGreaterThan(percentage);
    }
    
    public Page<Student> getAllStudentsWithPagination(int pageNumber, int pageSize) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        return studentRepository.findAll(pageable);
    }
    
}
