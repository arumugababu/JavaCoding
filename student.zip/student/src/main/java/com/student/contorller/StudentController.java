package com.student.contorller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.student.model.Student;
import com.student.services.StudentService;

@Controller
public class StudentController {
    @Autowired
    private StudentService studentService;

    @GetMapping("/students")
    public String showStudentList(Model model) {
        List<Student> students = studentService.getAllStudents();
        model.addAttribute("students", students);
        return "student-list";
    }

    @GetMapping("/students/add")
    public String showAddStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "add-student";
    }

    @PostMapping("/students/add")
    public String addStudent(@ModelAttribute("student") Student student) {
        studentService.saveStudent(student);
        return "redirect:/students";
    }

    @GetMapping("/students/edit/{id}")
    public String showEditStudentForm(@PathVariable Long id, Model model) {
        Student student = studentService.getStudentById(id);
        model.addAttribute("student", student);
        return "edit-student";
    }
    
    @GetMapping("/students/view/{id}")
    public String showViewStudentForm(@PathVariable Long id, Model model) {
        Student student = studentService.getStudentById(id);
        model.addAttribute("student", student);
        return "view-student";
    }

    @PostMapping("/students/edit")
    public String editStudent(@ModelAttribute("student") Student student) {
        studentService.saveStudent(student);
        return "redirect:/students";
    }

    @GetMapping("/students/delete/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteStudentById(id);
        return "redirect:/students";
    }
    
    // Mapping to list students with percentage greater than 80%
    @GetMapping("/students/high-percentage")
    public String getStudentsWithHighPercentage(Model model) {
        List<Student> highPercentageStudents = studentService.getStudentsWithPercentageGreaterThan(80.0);
        model.addAttribute("students", highPercentageStudents);
        return "student-list";
    }
    
 // Mapping to show the search page
    @GetMapping("/students/search-page")
    public String showSearchPage() {
        return "search-students";
    }
    
    // Mapping to handle the search request and display the results
    @GetMapping("/students/search")
    public String searchStudents(@RequestParam("searchType") String searchType,
                                 @RequestParam("searchValue") String searchValue,
                                 Model model) {

        List<Student> searchResults = new ArrayList<>();

        if ("name".equals(searchType)) {
            searchResults = studentService.getStudentsByName(searchValue);
        } else if ("id".equals(searchType)) {
            try {
                long id = Long.parseLong(searchValue);
                Student student = studentService.getStudentById(id);
                if (student != null) {
                    searchResults.add(student);
                }
            } catch (NumberFormatException e) {
                // Handle invalid ID input
            }
        } else if ("percentage".equals(searchType)) {
            try {
                double percentage = Double.parseDouble(searchValue);
                searchResults = studentService.getStudentsByPercentageGreaterThan(percentage);
            } catch (NumberFormatException e) {
                // Handle invalid percentage input
            }
        }

        model.addAttribute("students", searchResults);
        return "student-list";
    }
    
    @GetMapping("/students/pagenation")
    public String listStudents(@RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "5") int size,
                               Model model) {

        Page<Student> studentPage = studentService.getAllStudentsWithPagination(page, size);
        List<Student> students = studentPage.getContent();

        model.addAttribute("students", students);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", studentPage.getTotalPages());

        return "student-listpage";
    }
}
