package com.dpt.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import com.dpt.dao.QueryExecutorDAO;
import com.dpt.util.QueryBuilderUtil;
import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Service
public class QueryExecutorService {

    private final QueryExecutorDAO queryExecutorDAO;

    @Value("${dynamic.selectfields}")
    private String selectFields;

    public QueryExecutorService(QueryExecutorDAO queryExecutorDAO) {
        this.queryExecutorDAO = queryExecutorDAO;
    }

    public String executeQueryAndGenerateCSV(MultiValueMap<String, String> formData) throws Exception {
        // ✅ QueryBuilderUtil now handles chunking & query creation
        List<String> queries = QueryBuilderUtil.buildChunkedQueries(formData);

        // ✅ Execute queries using ThreadPoolExecutor
        ExecutorService executorService = Executors.newFixedThreadPool(queries.size());
        List<Future<List<String[]>>> futures = new ArrayList<>();

        for (String query : queries) {
            futures.add(executorService.submit(() -> queryExecutorDAO.executeQuery(query)));
        }

        // ✅ Collect results
        List<String[]> allResults = new ArrayList<>();
        for (Future<List<String[]>> future : futures) {
            allResults.addAll(future.get());
        }

        executorService.shutdown();
        return writeResultsToCSV(allResults);
    }

    private String writeResultsToCSV(List<String[]> data) throws IOException {
        String filePath = "output.csv";
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            writer.writeNext(selectFields.split(",")); 
            writer.writeAll(data);
        }
        return filePath;
    }
}
