package com.dpt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

import com.dpt.config.DynamicConfig;

@SpringBootApplication
@ComponentScan(basePackages = "com.dpt")
@EnableConfigurationProperties(DynamicConfig.class)  
public class DptApplication {

	public static void main(String[] args) {
		SpringApplication.run(DptApplication.class, args);
	}

}
