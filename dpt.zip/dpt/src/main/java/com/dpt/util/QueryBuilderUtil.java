package com.dpt.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class QueryBuilderUtil {

    private static String selectFields;
    private static String orderByFields;
    private static int chunkSize; // ✅ New chunk size configuration

    @Value("${dynamic.selectfields}")
    public void setSelectFields(String selectFields) {
        QueryBuilderUtil.selectFields = selectFields;
    }

    @Value("${dynamic.orderby}")
    public void setOrderByFields(String orderByFields) {
        QueryBuilderUtil.orderByFields = orderByFields;
    }

    @Value("${query.chunk.days}")  
    public void setChunkSize(int chunkSize) {
        QueryBuilderUtil.chunkSize = chunkSize;
    }

    
    public static List<String> buildChunkedQueries(MultiValueMap<String, String> formData) {
        List<String> queries = new ArrayList<>();

        String baseQuery = "SELECT " + selectFields + " FROM TESTTRAN_DTL WHERE ";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

        // ✅ Extract 'createdate' range
        List<String> createdDates = formData.get("createdate");
        if (createdDates != null && createdDates.size() == 2) {
            LocalDate startDate = LocalDate.parse(createdDates.get(0), formatter);
            LocalDate endDate = LocalDate.parse(createdDates.get(1), formatter);

            while (!startDate.isAfter(endDate)) {
                LocalDate tempEnd = startDate.plusDays(chunkSize - 1);
                if (tempEnd.isAfter(endDate)) {
                    tempEnd = endDate;
                }

                // ✅ Use StringBuilder inside loop
                StringBuilder chunkQueryBuilder = new StringBuilder(baseQuery);
                chunkQueryBuilder.append(" createdate BETWEEN TO_DATE('")
                        .append(startDate.format(formatter)).append("', 'DD-MON-YYYY') AND TO_DATE('")
                        .append(tempEnd.format(formatter)).append("', 'DD-MON-YYYY')");

                // ✅ Append additional filters
                formData.forEach((key, values) -> {
                    if (!key.equalsIgnoreCase("createdate")) {
                        List<String> validValues = values.stream()
                                .filter(value -> value != null && !value.isEmpty())
                                .collect(Collectors.toList());

                        if (!validValues.isEmpty()) {
                            String condition = validValues.stream()
                                    .map(value -> "'" + value + "'")
                                    .collect(Collectors.joining(", "));
                            chunkQueryBuilder.append(" AND ").append(key).append(" IN (").append(condition).append(")");
                        }
                    }
                });

                // ✅ Append GROUP BY Clause
                if (orderByFields != null && !orderByFields.trim().isEmpty()) {
                    chunkQueryBuilder.append(" GROUP BY ").append(orderByFields);
                }

                queries.add(chunkQueryBuilder.toString());
                startDate = tempEnd.plusDays(1);
            }
        }

        return queries;
    }

    
}
