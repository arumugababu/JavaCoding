package com.dpt.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dpt.model.Transaction;
import com.dpt.service.QueryExecutorService;

@Controller
public class FormController {

	@Autowired
	private Transaction transaction; // Autowiring the Transaction bean
	@Autowired
	private QueryExecutorService queryExecutorService;

	@GetMapping("/form")
	public String loadFormPage(Model model) {
		// Add fields and labels to the model for use in Thymeleaf
		model.addAttribute("fields", transaction.getFields());
		model.addAttribute("labels", transaction.getLabels());
		return "form"; // Return the form.html page
	}

	/*@PostMapping("/formData")
	public String handleFormSubmission(@RequestParam Map<String, String> formData, Model model) {
		if (formData.isEmpty()) {
			return "No data received!";
		}

		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

		formData.replaceAll((key, value) -> {
			if (key.toLowerCase().contains("date")) {
				try {
					LocalDate date = LocalDate.parse(value, inputFormatter);
					return date.format(outputFormatter);
				} catch (Exception e) {
					System.err.println("Skipping invalid date format for key: " + key + ", value: " + value);
				}
			}
			return value;
		});

		formData.forEach((key, value) -> System.out.println("Field: " + key + " => Value: " + value));

		model.addAttribute("formData", formData);

		return "form";
	}*/
	


	/*@PostMapping("/formData")
	public String handleFormSubmission(@RequestParam MultiValueMap<String, String> formData, Model model) {
	    if (formData.isEmpty()) {
	        return "No data received!";
	    }

	    DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

	    formData.forEach((key, values) -> {
	        if (key.toLowerCase().contains("date")) {
	            for (int i = 0; i < values.size(); i++) {
	                try {
	                    LocalDate date = LocalDate.parse(values.get(i), inputFormatter);
	                    values.set(i, date.format(outputFormatter));
	                } catch (Exception e) {
	                    System.err.println("Skipping invalid date format for key: " + key + ", value: " + values.get(i));
	                }
	            }
	        }
	    });

	    formData.forEach((key, values) -> System.out.println("Field: " + key + " => Values: " + values));

	    model.addAttribute("formData", formData);
	    String test = null;
		try {
			test = queryExecutorService.executeQueryAndGenerateCSV(formData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    //String query = QueryBuilderUtil.buildDynamicQuery(formData);
	    System.out.println("Generated Query: " + test);

	    model.addAttribute("query", test);
	    return "form";
	}*/
	
	
	@PostMapping("/formData")
	public String handleFormSubmission(@RequestParam MultiValueMap<String, String> formData, Model model) {
	    if (formData.isEmpty()) {
	        return "No data received!";
	    }

	    DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

	    formData.forEach((key, values) -> {
	        if (key.toLowerCase().contains("date")) {
	            for (int i = 0; i < values.size(); i++) {
	                try {
	                    LocalDate date = LocalDate.parse(values.get(i), inputFormatter);
	                    values.set(i, date.format(outputFormatter));
	                } catch (Exception e) {
	                    System.err.println("Skipping invalid date format for key: " + key + ", value: " + values.get(i));
	                }
	            }
	        }
	    });

	    String filePath = null;
	    try {
	        filePath = queryExecutorService.executeQueryAndGenerateCSV(formData);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    model.addAttribute("filePath", filePath);
	    return "success"; // Redirect to the new success page
	}
	
	@GetMapping("/download")
	public ResponseEntity<Resource> downloadFile(@RequestParam String filePath) throws IOException {
	    File file = new File(filePath);
	    InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

	    return ResponseEntity.ok()
	            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName())
	            .contentType(MediaType.APPLICATION_OCTET_STREAM)
	            .body(resource);
	}



}
