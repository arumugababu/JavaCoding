package com.dpt.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.dpt.config.DynamicConfig;

import java.util.Map;

@Component
public class Transaction {

    private Map<String, String> fields;
    private Map<String, String> labels;

    @Autowired
    public Transaction(DynamicConfig dynamicConfig) {
        this.fields = dynamicConfig.getFields();
        this.labels = dynamicConfig.getLabels();
    }

    public Map<String, String> getFields() {
        return fields;
    }

    public void setFields(Map<String, String> fields) {
        this.fields = fields;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }
}
