package com.employee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp0077")
public class EmpModel {
   
	@Column
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empId;
	@Column
    private String empUserName;
	@Column
    private String empPassword;
	@Column
    private String empEmailId;
	@Column
    private String empMobileNo;
	@Column
    private String empAddress;
	@Column
    private String empAdminLogin;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpUserName() {
		return empUserName;
	}
	public void setEmpUserName(String empUserName) {
		this.empUserName = empUserName;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	public String getEmpEmailId() {
		return empEmailId;
	}
	public void setEmpEmailId(String empEmailId) {
		this.empEmailId = empEmailId;
	}
	public String getEmpMobileNo() {
		return empMobileNo;
	}
	public void setEmpMobileNo(String empMobileNo) {
		this.empMobileNo = empMobileNo;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public String getEmpAdminLogin() {
		return empAdminLogin;
	}
	public void setEmpAdminLogin(String empAdminLogin) {
		this.empAdminLogin = empAdminLogin;
	}

	
}
