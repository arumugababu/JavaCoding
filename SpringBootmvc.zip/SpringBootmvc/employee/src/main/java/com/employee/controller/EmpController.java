package com.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.employee.model.EmpModel;
import com.employee.service.EmpService;

@Controller
public class EmpController {

	@Autowired
	public EmpService empService;

	@GetMapping("/register")
	public String empRegistor(Model model) {
		EmpModel empModel = new EmpModel();
		model.addAttribute("register", empModel);
		return "register";
	}

	@GetMapping("/login")
	public String loginPage(Model model) {
		EmpModel empModel = new EmpModel();
		model.addAttribute("register", empModel);
		return "emplogin";
	}

	@PostMapping("/empSave")
	public String empSave(@ModelAttribute("empSave") EmpModel empModel) {
		empService.empSave(empModel);
		return "redirect:/empGetAll";
	}

	@GetMapping("/empGetAll")
	public String empGetAll(Model model) {
		model.addAttribute("empGetAll", empService.empGetAll());
		return "empGetAll";
	}

	@RequestMapping("/empDelete/{empId}")
	public String empDelete(@PathVariable("empId") int id, Model model) {
		empService.empDelete(id);
		return "redirect:/empGetAll";
	}

	@GetMapping("/empGet/{empId}")
	public String empGet(@PathVariable("empId") int id, Model model) {
		model.addAttribute("empGet", empService.empGet(id));
		return "editEmp";
	}

	@PostMapping("/empLogincheck")
	public String empLogin(@ModelAttribute("empLogincheck") EmpModel empModel, Model model) {
		EmpModel empLogin = new EmpModel();
		empLogin = empService.empGetUser(empModel.getEmpUserName());
		System.out.println("empLogin db value" + empLogin.getEmpUserName());
		System.out.println("empLogin db value" + empLogin.getEmpPassword());
		// if(empLogin!=null) {
		if (empLogin.getEmpUserName().equals(empModel.getEmpUserName())
				&& empLogin.getEmpPassword().equals(empModel.getEmpPassword())) {
			model.addAttribute("empGetAll", empLogin);
			return "sigleEmp";
		} else {
			EmpModel empModel2 = new EmpModel();
			model.addAttribute("register", empModel2);
			return "invaliduser";
		}
		// }
		// return "error";
	}
}