package com.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dao.EmpDao;
import com.employee.model.EmpModel;

@Service
public class EmpService {

	@Autowired
	public EmpDao empDao;

	public EmpModel empSave(EmpModel empModel) {
		return empDao.save(empModel);

	}

	public List<EmpModel> empGetAll() {
		List<EmpModel> empModelAll = new ArrayList<EmpModel>();
		empDao.findAll().forEach(empModel -> empModelAll.add(empModel));
		return empModelAll;

	}

	public void empDelete(int id) {
		empDao.deleteById(id);

	}
   
	public EmpModel empGet(int id) {
		return empDao.findById(id).get();

	}
	
	public EmpModel empGetUser(String userName) {
		return empDao.findByEmpUserName(userName);

	}
	
	
	
	
}
