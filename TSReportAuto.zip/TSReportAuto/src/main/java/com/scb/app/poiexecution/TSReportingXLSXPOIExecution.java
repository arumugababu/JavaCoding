package com.scb.app.poiexecution;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;


@Component
public class TSReportingXLSXPOIExecution {

	public void incidentXLSXPOIExecution(List<Map<String, Object>> data) {
		System.out.println("======incidentXLSXPOIExecution========");
		
		 
	    
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Incident Remedy Report");
		Set<String> keyset = data.get(0).keySet();
		int rownum = 0;
		for (Map<String, Object> entry : data) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(rownum++);
			System.out.println("entry : " + entry);
			//Object[] objArr = entry.get(key);
			int cellnum = 0;
			if(rownum == 1) {
				for (String key : keyset) {
					System.out.println(rownum + ": " + key);
					Object obj = key;
					// this line creates a cell in the next column of that row
					Cell cell = row.createCell(cellnum++);
					if (obj instanceof String)
						cell.setCellValue((String) obj);
					else if (obj instanceof Integer)
						cell.setCellValue((Integer) obj);
					else
						cell.setCellValue(obj + "");
				}
				row = sheet.createRow(rownum++);
				cellnum = 0;
			} 
			for (String key : keyset) {
				System.out.println(rownum + ": " + key);
				Object obj = entry.get(key);
				// this line creates a cell in the next column of that row
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
				else
					cell.setCellValue(obj + "");
			}
		}
		try {
			System.out.println("try in side.....");
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss");	    
		    Calendar calendar = Calendar.getInstance();	     
		    String strDate = formatter.format(calendar.getTime());
		    System.out.println(" date is:::::::"+formatter.format(calendar.getTime()));
		    String fileName = "C:\\Users\\Nithish Kabilan a\\Desktop\\JTS 2020 Details\\SCBTESTREPORTS\\RemedyReprot"+strDate+".xls";
			FileOutputStream out = new FileOutputStream(
					new File(fileName));
			workbook.write(out);
			out.close();
			//System.out.println("Remedy_IncReprot"+formatter.format(calendar.getTime())+".xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
