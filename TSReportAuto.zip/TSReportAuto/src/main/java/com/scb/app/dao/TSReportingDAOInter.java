package com.scb.app.dao;

import java.util.List;
import java.util.Map;

public interface TSReportingDAOInter {
	
	public String incidentManagementTS(String remedyQuery);
	
	public List<Map<String, Object>> executeQuery(String query);

}
