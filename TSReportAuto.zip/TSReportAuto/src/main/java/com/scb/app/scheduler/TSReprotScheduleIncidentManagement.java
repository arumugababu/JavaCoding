package com.scb.app.scheduler;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.scb.app.services.TSReportServicesInter;
import com.scb.app.sqlquers.TSReportingSqlQuerys;

@Component
public class TSReprotScheduleIncidentManagement {

	@Autowired
	private TSReportServicesInter tsReportServicesInter;

	@Autowired
	private TSReportingSqlQuerys tsReportingSqlQuerys;

	//@Scheduled(cron = "1 * * * * ?")
	//@Scheduled(fixedDelay = 20000, initialDelay = 10000)
	public void cronJobSch() {

		System.out.println("tsReportingSqlQuerys::::::::" + tsReportingSqlQuerys.getIncident001());
		String remedyincident001 = tsReportingSqlQuerys.getIncident001();
		tsReportServicesInter.incidentManagementTS(remedyincident001);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Date now = new Date();
		String strDate = sdf.format(now);
		
		// read excel_1
		// list 200 job
		// loop list
		// dynamice job() --- start - excel_2
		// fixedDelay = 20000

		System.out.println("Java cron job expression:: " + strDate);
	}

//	@Scheduled(fixedDelay = 10000, initialDelay = 10000)
//	public void fixedDelaySch() {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//		Date now = new Date();
//		String strDate = sdf.format(now);
//		System.out.println("Fixed Delay scheduler:: " + strDate);
//	}

}
