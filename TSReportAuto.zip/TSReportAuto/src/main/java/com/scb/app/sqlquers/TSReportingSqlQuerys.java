package com.scb.app.sqlquers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


@Component
@PropertySource("classpath:application-sqlquery.properties")
@ConfigurationProperties
public class TSReportingSqlQuerys {
	
	@Value("${remedyincident001}")
	private String incident001;

	public String getIncident001() {
		return incident001;
	}

	public void setIncident001(String incident001) {
		this.incident001 = incident001;
	}
	
	
}
