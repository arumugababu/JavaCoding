package com.scb.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TSReportAutoController {

	private String folderpath = "";

	@SuppressWarnings("rawtypes")
	@GetMapping("/")
	public ModelAndView showLoginPage(Model model) {
		System.out.println("==========First Web method========");
		model.addAttribute("message", "Welcome to Java4s Spring Boot Tutorials");
		folderpath = "C://Mytestfiles";
		Map filesList = listFolders(folderpath);
		return new ModelAndView("welcomePage", "filesList", filesList);
	}

	@GetMapping("/indexpage")
	@SuppressWarnings("rawtypes")
	public ModelAndView indexpage(Model model) {
		System.out.println("==========two Web method========");
		model.addAttribute("message", "Welcome to Java4s Spring Boot Tutorials");

		Map filesList = listFolders("C:\\Mytestfiles");

		return new ModelAndView("index", "filesList", filesList);
	}

	@SuppressWarnings("rawtypes")
	public Map listFolders(String directoryName) {
		System.out.println("::::::::::listFolders::::::::::");
		File directory = new File(directoryName);
		Map<String, Object> filesList = new HashMap<>();
		// get all the files from a directory
		File[] fList = directory.listFiles();
		System.out.println("file size" + fList.length);
		for (File file : fList) {
			if (file.isFile()) {
				filesList.put(file.getName(), file);
				System.out.println();
				
			}
		}
		System.out.println(filesList);
		return filesList;
	}

	@RequestMapping(value = "/download", method = RequestMethod.GET)
	public ResponseEntity<Object> downloadFile(@RequestParam("fileName") String fileName) throws IOException {

		System.out.println("Method inside...download.." + fileName);
		// String filename = "D:/work/tree.jpg";
		String filename = folderpath + "/" + fileName;
		// sString filename = fileName;
		File file = new File(filename);
		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");

		ResponseEntity<Object> responseEntity = ResponseEntity.ok().headers(headers).contentLength(file.length())
				.contentType(MediaType.parseMediaType("application/pdf")).body(resource);

		return responseEntity;
	}

}

// URL: http://localhost:8080/springbootmvc/