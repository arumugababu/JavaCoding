package com.scb.app.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.persistence.Query;
import javax.persistence.Tuple;
import javax.persistence.TupleElement;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scb.app.util.HibernateUtil;
import com.scb.app.poiexecution.TSReportingXLSXPOIExecution;



@Repository
public class TSReportingDAOImpl implements TSReportingDAOInter {
	
	@Autowired
	private TSReportingXLSXPOIExecution TSReportingXLSXPOIExecution;

	@SuppressWarnings("unchecked")
	@Override
	public String incidentManagementTS(String remedyQuery) {
		System.out.println("incidentManagementTS DAO Layer Meothed Called Successfully..");
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
		//	@SuppressWarnings("unchecked")
		//	List<Object[]> list = session.createNativeQuery("SELECT PERSONID,name,AGE FROM Person").list();
			//hibernateUtil(remedyQuery);
			TSReportingXLSXPOIExecution.incidentXLSXPOIExecution(executeQuery(remedyQuery));
//			for (Object[] objects : list) {
//				//BigInteger id = (BigInteger) objects[0];
//				//String name = (String) objects[3];
//				System.out.println("Value 111"+objects[0]);
//				System.out.println("Value 222"+objects[1]);
//				System.out.println("Value 333"+objects[2]);
//
//				//System.out.println("Person Id:" + id);
//				//System.out.println("Person Name:" + name);
//			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	///sessionFactory.getCurrentSession().createQuery("DELETE FROM Employee00033 WHERE id = 8").executeUpdate();
		System.out.println("incidentManagementTS DAO Layer out=============> Meothed Called Successfully..");
		return null;
	}
	
	public void hibernateUtil(String sqlQuery){
		 
	        Map<String, Object[]> data = new TreeMap<String, Object[]>(); 
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			
			StringBuilder builder = new StringBuilder();
			// Without alias of the column names
    		//String sqlQuery = "SELECT E.EMP_ID, E.NAME, E.DESIGNATION , D.NAME FROM EMPLOYEE E, DEPARTMENT D WHERE E.DPT_ID=D.DPT_ID";

    		// With and without alias name of the columns
//			String sqlQuery = "SELECT E.EMP_ID AS EEMP_ID,E.NAME AS ENAME,E.DESIGNATION AS EDESIGNATION,D.NAME AS DNAME FROM  EMPLOYEE E, DEPARTMENT D WHERE E.DPT_ID=D.DPT_ID";

			if (!sqlQuery.contains("AS") && !sqlQuery.contains("as")) {
				if (sqlQuery.contains("FROM") || sqlQuery.contains("from")) {
					String[] strArray = sqlQuery.split("FROM");
					if (strArray.length == 0) {
						strArray = sqlQuery.split("from");
					}

					String[] strColumnArray = strArray[0].split(",");
					System.out.println("Column Length >>> " + strColumnArray.length);

					for (int i = 0; i < strColumnArray.length; i++) {
						String strColumnName = strColumnArray[i];
						String strAliseColumnName = "";
						if (i == 0) {
							if (strColumnName.contains("SELECT") || strColumnName.contains("select")) {
								strAliseColumnName = removeDOT(strColumnName.split(" ")[1]);
								builder.append(strColumnName.split(" ")[0]).append(" ")
										.append(strColumnName.split(" ")[1] + " AS " + strAliseColumnName).append(",");
							}
						} else {
							strColumnName = strColumnName.trim();
							strAliseColumnName = removeDOT(strColumnName);
							if (i == strColumnArray.length - 1) {
								builder.append(strColumnName).append(" AS ").append(strAliseColumnName);
							} else {
								builder.append(strColumnName).append(" AS ").append(strAliseColumnName).append(",");
							}
						}
					}

					builder.append(" FROM " + strArray[1]);
				}
			}

			String query = builder.toString().length() > 0 ? builder.toString() : sqlQuery;
			
			
			System.out.println("sqlQuery >>> " + query);
			Query q = session.createNativeQuery(query, Tuple.class);
			@SuppressWarnings("unchecked")
			List<Tuple> result = q.getResultList();
			Map<String, String> queryColumnMap = new LinkedHashMap<String, String>();

			builder = new StringBuilder(); // Here create new object
			int mapColumnCount = 0;
			for (int i = 0; i < result.size(); i++) {
				Tuple tuple = result.get(i);
				if (i == 0) {
					List<TupleElement<?>> s = result.get(0).getElements();
					Object[] columnNames = new Object[s.size()];
					for (int k = 0; k < s.size(); k++) {
						if (k == s.size() - 1) {
							builder.append(s.get(k).getAlias()).append("\n");
							columnNames[k] = s.get(k).getAlias();
							System.out.print(i+" Column Name "+s.get(k).getAlias()+" ");
						} else {
							builder.append(s.get(k).getAlias() + ",");
							columnNames[k] = s.get(k).getAlias();
							System.out.print(i+" Column Name "+s.get(k).getAlias()+" ");
						}
						queryColumnMap.put(s.get(k).getAlias(), s.get(k).getAlias());
					}
					data.put((i)+"", columnNames);
					mapColumnCount = queryColumnMap.size();
				}
				System.out.println();
				int mapCount = 0;
				Object[] columnValues = new Object[queryColumnMap.entrySet().size()];
				for (Map.Entry<String, String> entry : queryColumnMap.entrySet()) {
					if (mapCount == mapColumnCount - 1) {
						builder.append(tuple.get(entry.getKey())).append("\n");
						columnValues[mapCount] = tuple.get(entry.getKey());
						System.out.print(mapCount+" Column values : "+tuple.get(entry.getKey())+" ");
					} else {
						builder.append(tuple.get(entry.getKey()) + ",");
						columnValues[mapCount] = tuple.get(entry.getKey());
						System.out.print(mapCount+" Column values : "+tuple.get(entry.getKey())+" ");
					}
					mapCount++;
					System.out.println();
				}
				data.put((1+i)+"", columnValues);
				
				
			}
			System.out.println(data);
			//poiWriting(data);
		//	TSReportingXLSXPOIExecution.incidentXLSXPOIExecution(data);
			System.out.println(builder.toString());
			System.out.println("DONE");
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (session != null) {
				session.close();
			}
		}
		//HibernateUtil.shutdown();
	}
	
	public static String removeDOT(String str) {
		return str.replaceAll("[-+.^:,]", "");

	}
	
	@Override
	public List<Map<String, Object>> executeQuery(String query) {
		Session local = HibernateUtil.getSessionFactory().openSession();
		Query q = null;
		List<Map<String, Object>> dataList = null;
		try {
			local.beginTransaction();
			System.out.println("Repository : executeQuery ...");
			long start = System.currentTimeMillis()/1000;
			q = local.createNativeQuery(query).setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
			dataList =  q.getResultList();
			for(Map<String, Object> obj  : dataList){
				System.out.println(obj);
			}
			long end = System.currentTimeMillis()/1000;
			
			System.out.println("hibernate query execute time is "+ (end-start) +"s from database");
			local.getTransaction().commit();
			local.close();
		} catch (Exception e) {
			if (local != null)
				local.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			if (local != null)
				local.close();
			local = null;
			q = null;
		}
		return dataList;
	}	
	


}
