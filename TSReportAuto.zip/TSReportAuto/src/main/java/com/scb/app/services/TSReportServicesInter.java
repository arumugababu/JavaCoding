package com.scb.app.services;

public interface TSReportServicesInter {
	
	public String incidentManagementTS(String remedyQuery);

}
