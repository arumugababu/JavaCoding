package com.scb.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.app.dao.TSReportingDAOInter;

@Service
public  class TSReportServicesImpl implements TSReportServicesInter {
	
	@Autowired
	private TSReportingDAOInter tsReportingDAOInter;

	public String incidentManagementTS(String remedyQuery) {
		System.out.println("incidentManagementTS Service Layer Meothed Called Successfully.." );
		tsReportingDAOInter.incidentManagementTS(remedyQuery);
		return "";
	}


}
