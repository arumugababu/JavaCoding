package com.scgbs.main;

import java.sql.Connection;
import java.util.List;

import org.apache.log4j.Logger;

import com.scgbs.util.AppUtil;
import com.scgbs.util.DBConnectionProvider;

public class Main
{
	private static final Logger logger = Logger.getLogger ( Main.class.getName () );
	public static void main ( String [] args )
	{
		long start = System.currentTimeMillis ();
		logger.info ( "BEGIN : Main Program started.......!" );
		try
		{
			DBConnectionProvider.getInstance ();

			// SELECT Orders.OrderID, Customers.CustomerName, Orders.OrderDate FROM Orders INNER JOIN Customers ON Orders.CustomerID=Customers.CustomerID;

			// With and without alias name of the columns
			// String sqlQuery = "SELECT E.EMP_ID AS EEMPID,E.NAME AS ENAME,E.DESIGNATION AS EDESIGNATION,D.NAME AS DNAME FROM EMPLOYEE E, DEPARTMENT D WHERE E.DPT_ID=D.DPT_ID";

			// Without alias of the column names
			// String sqlQuery = "SELECT E.EMP_ID, E.NAME, E.DESIGNATION , D.NAME FROM EMPLOYEE E, DEPARTMENT D WHERE E.DPT_ID=D.DPT_ID";

			// Join query of the column names
			//String sqlQuery = "SELECT EM.EMP_ID, EM.NAME, EM.DESIGNATION , D.NAME FROM EMPLOYEE EM INNER JOIN  DEPARTMENT D ON EM.DPT_ID=D.DPT_ID";
			String sqlQuery = "select RESUMEID,NAME from naukricomdata";
			// SELECT EM.EMP_ID AS EMEMP_ID,EM.NAME AS EMNAME,EM.DESIGNATION AS EMDESIGNATION,D.NAME AS DNAME FROM EMPLOYEE EM INNER JOIN DEPARTMENT D ON EM.DPT_ID=D.DPT_ID
			String query = AppUtil.sqlQuery ( sqlQuery );
			logger.info ( "Query : " + query );
			Connection connection = DBConnectionProvider.getConnection ();
			List <String> mapQueryColumns = AppUtil.getQueryColumns ( connection, query );
			if ( mapQueryColumns.size () > 0 )
			{
				List <String> mapQueryDatas = AppUtil.getQueryDatas ( connection, query, mapQueryColumns );
				mapQueryDatas.add ( 0, mapQueryColumns.get ( 0 ) );
				AppUtil.writeExcel ( mapQueryDatas );
			}
			DBConnectionProvider.closeConnection ();
		}
		catch ( Exception e )
		{
			logger.error ( "ERROR : main >>  " + e.getMessage () );
		}
		logger.info ( "END : Main Program end time : " + ( System.currentTimeMillis () - start ) + "s" );
	}

}
