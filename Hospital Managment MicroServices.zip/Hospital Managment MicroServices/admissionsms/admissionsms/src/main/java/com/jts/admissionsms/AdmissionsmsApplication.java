package com.jts.admissionsms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdmissionsmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdmissionsmsApplication.class, args);
	}

}
