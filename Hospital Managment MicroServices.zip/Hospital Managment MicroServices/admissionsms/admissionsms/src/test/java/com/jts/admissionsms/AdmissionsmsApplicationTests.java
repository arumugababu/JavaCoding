package com.jts.admissionsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmissionsmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
