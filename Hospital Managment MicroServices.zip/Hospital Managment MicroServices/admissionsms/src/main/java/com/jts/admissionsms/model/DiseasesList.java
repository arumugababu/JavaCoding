package com.jts.admissionsms.model;

import java.util.List;

public class DiseasesList {
	
	private List<Disease>  disease;
	
	public void setDisease(List<Disease> disease) {
		this.disease = disease;
	}
	
	public List<Disease> getDisease() {
		return disease;
	}

}
