package com.jts.admissionsms.model;

import java.util.List;

public class EmployeeList {
	
	public List<EmployeeModel> employees;
	
	public void setEmployees(List<EmployeeModel> employees) {
		this.employees = employees;
	}
	
	public List<EmployeeModel> getEmployees() {
		return employees;
	}

}
