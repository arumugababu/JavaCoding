package com.jts.admissionsms.resource;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.jts.admissionsms.model.DiseasesList;
import com.jts.admissionsms.model.EmployeeList;
import com.jts.admissionsms.model.Patient;

@RestController
@RequestMapping("/admissions")
public class AdmissionsResource {

	@Autowired
	private RestTemplate restTemplate;

	List<Patient> patientList = Arrays.asList(
			new Patient("P1", "KANNAN", "TN-CH-TAMBARAM"),
			new Patient("P2", "RAJA", "TN-CH-CHROMPET"),
			new Patient("P3", "KUMAR", "TN-TR-TRICH"),
			new Patient("P4", "RAMKUMAR", "TN-TR-TRICH"));

	@RequestMapping("/physicians")
	public EmployeeList getPhysicians() {

		EmployeeList employeeList = restTemplate.getForObject("http://hr-services/hr/employees",
				EmployeeList.class);

		return employeeList;
	}
	
	@RequestMapping("/diseases")
	public DiseasesList  getDiseases() {

		DiseasesList  diseasesList  = restTemplate.getForObject("http://pathology-services/pathology/diseases",
				DiseasesList.class);

		return diseasesList;
	}

	@RequestMapping("/patients")
	public List<Patient> getPatients() {

		return patientList;

	}

	@RequestMapping("/patients/{id}")
	public Patient getPatientsByIf(@PathVariable("id") String id) {

		Patient singlePatient = patientList.stream().filter(patients -> id.equals(patients.getId())).findAny()
				.orElse(null);

		return singlePatient;
	}

}
