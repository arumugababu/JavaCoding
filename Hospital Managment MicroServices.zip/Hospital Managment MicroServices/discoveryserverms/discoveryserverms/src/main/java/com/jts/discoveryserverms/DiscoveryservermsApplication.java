package com.jts.discoveryserverms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscoveryservermsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoveryservermsApplication.class, args);
	}

}
