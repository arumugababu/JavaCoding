package com.jts.Pathologyservicems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PathologyservicemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
