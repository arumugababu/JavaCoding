package com.jts.Pathologyservicems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PathologyservicemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PathologyservicemsApplication.class, args);
	}

}
