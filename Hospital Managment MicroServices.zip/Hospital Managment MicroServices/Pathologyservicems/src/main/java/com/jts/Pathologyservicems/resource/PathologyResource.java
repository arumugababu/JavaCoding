package com.jts.Pathologyservicems.resource;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jts.Pathologyservicems.Disease.Disease;
import com.jts.Pathologyservicems.Disease.DiseasesList;

@RestController
@RequestMapping("/pathology")
public class PathologyResource {

	List<Disease> diseases = Arrays.asList(

			new Disease("D1", "Fever", "Paracetamol"), 
			new Disease("D2", "coronavirus", "No Medication"),
			new Disease("D3", "ortho", "therapy")

	);
	
	@RequestMapping("/diseases")
	public DiseasesList getDiseases(){
		
		DiseasesList diseasesList = new DiseasesList();
		diseasesList.setDisease(diseases);
		return diseasesList;
	}
	
	//Old method we are going to wirte new method above
	/*@RequestMapping("/diseases")
	public List<Disease> getDiseases(){
		return diseaseList;
	}*/
	
	@RequestMapping("/diseases/{id}")
	public Disease getDiseaseById(@PathVariable("id") String id){
		
		Disease diseaseSingle = diseases.stream().filter(disease->id.equals(disease.getId())).findAny().orElse(null);
		
		return diseaseSingle;
		
	}

}
