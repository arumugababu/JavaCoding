package com.jts.hrservicems.resources;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jts.hrservicems.model.EmployeeList;
import com.jts.hrservicems.model.EmployeeModel;

@RestController
@RequestMapping("/hr")
public class HrResource {

	List<EmployeeModel> employeeModel = Arrays.asList(new EmployeeModel("E1", "JOHAN", "R", "Doctor"),
			new EmployeeModel("E2", "BALA", "M", "Doctor-3"), new EmployeeModel("E3", "Meena", "R", "Nursing"),
			new EmployeeModel("E4", "HEMANATHA", "R", "MEDITECH"));

	@RequestMapping("/employees")
	public EmployeeList getEmployees() {
		EmployeeList employeeList = new EmployeeList();
		employeeList.setEmployees(employeeModel);
		return employeeList;

	}

	// Old Method we used already.. above is this new meother.
	/*
	 * @RequestMapping("/employees") public List<EmployeeModel> getEmployees() {
	 * return employeeModel;
	 * 
	 * }
	 */

	@RequestMapping("/employees/{id}")
	public EmployeeModel getEmployeeById(@PathVariable("id") String id) {

		EmployeeModel employeeSigle = employeeModel.stream().filter(employee -> id.equals(employee.getId())).findAny()
				.orElse(null);

		return employeeSigle;

	}

}
