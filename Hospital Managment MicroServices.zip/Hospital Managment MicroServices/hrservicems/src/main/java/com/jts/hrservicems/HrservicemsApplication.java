package com.jts.hrservicems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class HrservicemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrservicemsApplication.class, args);
	}

}
