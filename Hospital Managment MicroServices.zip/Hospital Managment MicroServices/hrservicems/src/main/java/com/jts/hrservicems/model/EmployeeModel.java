package com.jts.hrservicems.model;

public class EmployeeModel {

	private String id;
	private String firstName;
	private String lasttName;
	private String speciality;

	public EmployeeModel() {

	}

	public EmployeeModel(String id, String firstName, String lasttName, String speciality) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lasttName = lasttName;
		this.speciality = speciality;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLasttName() {
		return lasttName;
	}

	public void setLasttName(String lasttName) {
		this.lasttName = lasttName;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

}
