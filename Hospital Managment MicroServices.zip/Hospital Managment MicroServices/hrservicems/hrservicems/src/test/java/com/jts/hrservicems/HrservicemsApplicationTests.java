package com.jts.hrservicems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrservicemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
