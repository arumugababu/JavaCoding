package com.jts.hrservicems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrservicemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrservicemsApplication.class, args);
	}

}
