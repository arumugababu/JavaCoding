package com.jts.bootats.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jts.bootats.model.AtsModel;

@Repository
public interface AtsDao extends CrudRepository<AtsModel, Integer>{

}



