package com.jts.bootats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootatsApplication.class, args);
	}

}
