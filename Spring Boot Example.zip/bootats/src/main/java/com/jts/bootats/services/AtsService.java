package com.jts.bootats.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.jts.bootats.dao.AtsDao;
import com.jts.bootats.exception.AtsException;
import com.jts.bootats.model.AtsModel;

@Service
public class AtsService {

	@Autowired
	public AtsDao atsDao;

	public AtsModel addAts(AtsModel atsModel) {
		System.out.println("Name" + atsModel.getAtsName());
		System.out.println("email" + atsModel.getAtsEmail());
		System.out.println("Address" + atsModel.getAtsAddress());
		return atsDao.save(atsModel);
	}

	public List<AtsModel> getAllAts() {

		List<AtsModel> ats = new ArrayList<AtsModel>();
		atsDao.findAll().forEach(atseach -> ats.add(atseach));
		return ats;
	}
	
	public AtsModel getAtsbyId(int atsId){
		
		Optional<AtsModel> optionalAtsModel = atsDao.findById(atsId);
		if(!optionalAtsModel.isPresent())
		{
			throw new AtsException("Application is not found in this database..");
		}
		
		return optionalAtsModel.get();
	}
	
	public void deletebyId(int atsId){
		atsDao.deleteById(atsId);
	}

}
