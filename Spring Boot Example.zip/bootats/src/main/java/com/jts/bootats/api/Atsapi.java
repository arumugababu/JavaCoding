package com.jts.bootats.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jts.bootats.model.AtsModel;
import com.jts.bootats.services.AtsService;

@RestController

public class Atsapi {

	@Autowired
	 AtsService atsService;

	@PostMapping("/atsapi")
	public AtsModel addAts(@RequestBody AtsModel atsModel) {
		System.out.println("Inside====Atsapi=== ");
		System.out.println("Name Atsapi" + atsModel.getAtsName());
		System.out.println("email Atsapi" + atsModel.getAtsEmail());
		System.out.println("Address Atsapi"+atsModel.getAtsAddress());
		return atsService.addAts(atsModel);
	}
	
	@GetMapping("/atsapi")
	public List<AtsModel> getAllAts(){
		
		return atsService.getAllAts();
	}
	
	@GetMapping("/atsapi/{atsId}")
	public AtsModel getAtsbyId(@PathVariable int atsId){
		
		return atsService.getAtsbyId(atsId);
	}
	
	@DeleteMapping("/atsapi/{atsId}")
	public void deletebyId(@PathVariable int atsId){
		
		 atsService.deletebyId(atsId);
	}


}
