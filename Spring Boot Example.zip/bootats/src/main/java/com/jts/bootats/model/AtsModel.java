package com.jts.bootats.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="atsmode0055")
public class AtsModel {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@Column
	private int AtsId;
	@Column
	private String AtsName;
	@Column
	private String AtsEmail;
	@Column
	private String AtsAddress;
	
	public int getAtsId() {
		return AtsId;
	}
	public void setAtsId(int atsId) {
		AtsId = atsId;
	}
	public String getAtsName() {
		return AtsName;
	}
	public void setAtsName(String atsName) {
		AtsName = atsName;
	}
	public String getAtsEmail() {
		return AtsEmail;
	}
	public void setAtsEmail(String atsEmail) {
		AtsEmail = atsEmail;
	}
	public String getAtsAddress() {
		return AtsAddress;
	}
	public void setAtsAddress(String atsAddress) {
		AtsAddress = atsAddress;
	}
	
	
	
	
}
